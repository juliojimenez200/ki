# Java Script Blackjack

Blackjack game made using HTML, CSS and JS

Cards are a JS class and shown in a HTML5 canvas.

https://github.com/magnitopic/BlackjackJS/assets/21156058/a31afdb8-df7c-4c54-94f3-b82f11617cf0

**_Note:_** Video is in Spanish

> I have a video up on YouTube explaning the program: [https://youtu.be/lbXRRl1SwXA](https://youtu.be/lbXRRl1SwXA)

## Image source

The card images are from [Wikipedia](https://commons.wikimedia.org/wiki/Category:SVG_playing_cards)
